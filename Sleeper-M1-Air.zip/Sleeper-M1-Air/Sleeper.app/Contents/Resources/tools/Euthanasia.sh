#!/bin/bash

# FUNCS

GO_TO_BED(){ pmset sleepnow; sleep 150; }
CHECK_DISPLAY(){ ioreg -r -k AppleClamshellState -d 4 | grep AppleClamshellState  |  egrep 'Yes|No' ; }


# MAIN
while true
    do  
        if [[ $( CHECK_DISPLAY ) = "Yes" ]]; then 
				GO_TO_BED
			else
				sleep 5
		fi
    done

