#!/bin/bash

export LC_ALL=en_US.UTF-8  
export LANG=en_US.UTF-8

DISPLAY_NOTIFICATION(){
"$ROOT"/terminal-notifier.app/Contents/MacOS/terminal-notifier -title "${TITLEMSG}" -sound Submarine -message "${MESSAGE}"
sleep 1
}

GET_TBW(){
	tbw=$("$ROOT"/smartctl -a $(diskutil list | grep -w "(internal):" | egrep -o "disk[0-9]") | grep "Data Units Written:" | sed 's/Data Units Written://'| tr ',' '.' | xargs)
	if [[ $(echo "$tbw" | awk -F [ '{print $NF}' | tr -d ] | awk '{print $NF}') = "TB" ]]; then 
		tbw2=$(bc <<< "$(echo "$tbw" | awk -F [ '{print $NF}' | tr -d ] | awk '{print $NR}')*1024" | cut -d. -f1)
	else
		tbw2=$(echo "$tbw" | awk -F [ '{print $NF}' | tr -d ] | awk '{print $NR}')
	fi
	tbw1=$(echo "$tbw" | awk -F [ '{print $NR}' | tr -d ' ')
}

SAVE_TBW_STAT(){ printf "$(date '+%D %H:%M')    $tbw\n"  >> "${logfile}"; }

SEND_ADD_WARNING(){
	case $1 in
	7) tbw_all=$((${tbw_time[7]}-${tbw_time_old[7]})); timesp="last half hour"; tbw_time_old[7]="${tbw2}" ;;
	1) tbw_all=$((${tbw_time[1]}-${tbw_time_old[1]})); timesp="last one hour" ; tbw_time_old[1]="${tbw2}" ;;
	2) tbw_all=$((${tbw_time[2]}-${tbw_time_old[2]})); timesp="last two hours"; tbw_time_old[2]="${tbw2}" ;;
	3) tbw_all=$((${tbw_time[3]}-${tbw_time_old[3]})); timesp="last three hours"; tbw_time_old[3]="${tbw2}"  ;;
	4) tbw_all=$((${tbw_time[4]}-${tbw_time_old[4]})); timesp="last six hours" ; tbw_time_old[4]="${tbw2}" ;;
	5) tbw_all=$((${tbw_time[5]}-${tbw_time_old[5]})); timesp="last 12 hours"; tbw_time_old[5]="${tbw2}"  ;;
	6) tbw_all=$((${tbw_time[6]}-${tbw_time_old[6]})); timesp="last 24 hours"; tbw_time_old[6]="${tbw2}" ;;
	8) timesp="last $sleep_time days"; for i in 1 2 3 4 5 6 7; do tbw_time_old[i]="${tbw2}"; done ;;
	esac
	TITLEMSG="WatchTBW warning: $tbw_all GB in the $timesp"
	MESSAGE="Data Units Written: $tbw"
	DISPLAY_NOTIFICATION
}	
	

CHECK_ADD_WARNING(){
	case $1 in
		7) if [[ $((${tbw_time[7]}-${tbw_time_old[7]})) -ge 30 ]]; then  SEND_ADD_WARNING 7;  fi ;;
		1) if [[ $((${tbw_time[1]}-${tbw_time_old[1]})) -ge 55 ]]; then SEND_ADD_WARNING 1;  fi ;;
		2) if [[ $((${tbw_time[2]}-${tbw_time_old[2]})) -ge 85 ]]; then SEND_ADD_WARNING 2; fi ;;
		3) if [[ $((${tbw_time[3]}-${tbw_time_old[3]})) -ge 155 ]]; then SEND_ADD_WARNING 3; fi ;;
		4) if [[ $((${tbw_time[4]}-${tbw_time_old[4]})) -ge 300 ]]; then  SEND_ADD_WARNING 4; fi ;;
		5) if [[ $((${tbw_time[5]}-${tbw_time_old[5]})) -ge 550 ]]; then  SEND_ADD_WARNING 5; fi ;;
		6) if [[ $((${tbw_time[6]}-${tbw_time_old[6]})) -ge 950 ]]; then  SEND_ADD_WARNING 6; fi ;;
		8) sleep_time=$((timer/48)); timer=48; SEND_ADD_WARNING 8 ;;
	esac
	
}

SET_INIT_DATA(){
	GET_TBW
	tbw_init="${tbw}"; tbw2_init="${tbw2}"; tbw1_init="${tbw1}"
	tbw_old="${tbw}"; tbw1_old="${tbw1}"; tbw2_old="${tbw2}"
	tbw_time=(); tbw_time_old=()
	for i in 1 2 3 4 5 6; do tbw_time[i]="${tbw2}"; done
	for i in 1 2 3 4 5 6; do tbw_time_old[i]="${tbw2}"; done
	timer=0; day_begin_time=$(date +%s)
}

# INIT
ROOT="/Users/$(whoami)/Library/Application Support/WatchTBW"
TITLEMSG="WatchTBW:"
SET_INIT_DATA
MESSAGE="Data Units Written: $tbw_init"
logfile="${ROOT}/tbwstat.log"
loc=$(defaults read -g AppleLocale | cut -d "_" -f1)
if [[ ! $loc = "ru" ]]; then loc="en"; fi

DISPLAY_NOTIFICATION

# MAIN
while true
    do  
		tbw_old="${tbw}"; tbw1_old="${tbw1}"; tbw2_old="${tbw2}"; tbw_time_old[7]="${tbw2}"
		if [[ $((timer%2)) = 0 ]]; then tbw_time_old[1]="${tbw2}"; fi
		if [[ $((timer%4)) = 0 ]]; then tbw_time_old[2]="${tbw2}"; fi
		if [[ $((timer%6)) = 0 ]]; then tbw_time_old[3]="${tbw2}"; fi
		if [[ $((timer%12)) = 0 ]]; then tbw_time_old[4]="${tbw2}"; fi
		if [[ $((timer%24)) = 0 ]]; then tbw_time_old[5]="${tbw2}"; fi
		if [[ $((timer%48)) = 0 ]]; then tbw_time_old[6]="${tbw2}"; fi
		SAVE_TBW_STAT
        sleep 1800; nowtime=$(($(date +%s)-day_begin_time))
        if [[ ${nowtime} -le 1805 ]]; then let "timer++"
          else 
			timer=$((timer+$((nowtime/1800))))
			if [[ ${timer} -gt 48 ]]; then CHECK_ADD_WARNING 8; fi
        fi 
	    GET_TBW
		if [[ $((timer%1)) = 0 && ! $((timer%2)) = 0 ]]; then tbw_time[7]="${tbw2}"; CHECK_ADD_WARNING 7; fi
		if [[ $((timer%2)) = 0 ]]; then tbw_time[1]="${tbw2}"; CHECK_ADD_WARNING 1; fi
		if [[ $((timer%4)) = 0 ]]; then tbw_time[2]="${tbw2}"; CHECK_ADD_WARNING 2; fi
		if [[ $((timer%6)) = 0 ]]; then tbw_time[3]="${tbw2}"; CHECK_ADD_WARNING 3; fi
		if [[ $((timer%12)) = 0 ]]; then tbw_time[4]="${tbw2}"; CHECK_ADD_WARNING 4; fi
		if [[ $((timer%24)) = 0 ]]; then tbw_time[5]="${tbw2}"; CHECK_ADD_WARNING 5; fi
		if [[ $((timer%48)) = 0 ]]; then tbw_time[6]="${tbw2}"; CHECK_ADD_WARNING 6; fi
		if [[ $timer -ge 48 ]]; then timer=1; SET_INIT_DATA; fi
    done

