#!/bin/bash

export PATH=/usr/local/bin:$PATH
export PATH="/opt/homebrew/bin:$PATH"

DISPLAY_NOTIFICATION(){
"$ROOT"/terminal-notifier.app/Contents/MacOS/terminal-notifier -title "${TITLEMSG}" -sound Submarine -message "${MESSAGE}"
sleep 1
}

GET_TBW(){
	tbw=$(smartctl -a $(diskutil list | grep -w "(internal):" | egrep -o "disk[0-9]") | grep "Data Units Written:" | sed 's/Data Units Written://'| tr ',' ' ' | xargs)
	tbw2=$(echo "$tbw" | awk -F [ '{print $NF}' | tr -d ] | awk '{print $NR}')
	tbw1=$(echo "$tbw" | awk -F [ '{print $NR}' | tr -d ' ')
}

SAVE_TBW_STAT(){ printf "$(date '+%D %H:%M')    $tbw\n"  >> "${logfile}"; }

SEND_WARNING(){
	TITLEMSG="WatchTBW warning: $((tbw2-tbw2_old)) GB for last half hour"
	MESSAGE="Data Units Written: $tbw"
	DISPLAY_NOTIFICATION
}

SEND_ADD_WARNING(){
	case $1 in
	1) tbw_all=$((${tbw_time[1]}-${tbw_time_old[1]})); timesp="last one hour" ;;
	2) tbw_all=$((${tbw_time[2]}-${tbw_time_old[2]})); timesp="last two hours" ;;
	3) tbw_all=$((${tbw_time[3]}-${tbw_time_old[3]})); timesp="last three hours" ;;
	4) tbw_all=$((${tbw_time[4]}-${tbw_time_old[4]})); timesp="last six hours" ;;
	5) tbw_all=$((${tbw_time[5]}-${tbw_time_old[5]})); timesp="last 12 hours" ;;
	6) tbw_all=$((${tbw_time[6]}-${tbw_time_old[6]})); timesp="last 24 hours" ;;
	esac
	TITLEMSG="WatchTBW warning: $tbw_all GB for $timesp"
	MESSAGE="Data Units Written: $tbw"
	DISPLAY_NOTIFICATION
}	
	

CHECK_ADD_WARNING(){
	case $1 in
		1) if [[ $((${tbw_time[1]}-${tbw_time_old[1]})) -ge 50 ]]; then SEND_ADD_WARNING 1; fi ;;
		2) if [[ $((${tbw_time[2]}-${tbw_time_old[2]})) -ge 80 ]]; then SEND_ADD_WARNING 2; fi ;;
		3) if [[ $((${tbw_time[3]}-${tbw_time_old[3]})) -ge 150 ]]; then SEND_ADD_WARNING 3; fi ;;
		4) if [[ $((${tbw_time[4]}-${tbw_time_old[4]})) -ge 230 ]]; then SEND_ADD_WARNING 4; fi ;;
		5) if [[ $((${tbw_time[5]}-${tbw_time_old[5]})) -ge 500 ]]; then SEND_ADD_WARNING 5; fi ;;
		6) if [[ $((${tbw_time[6]}-${tbw_time_old[6]})) -ge 900 ]]; then SEND_ADD_WARNING 6; fi ;;
	esac
	
}

SET_INIT_DATA(){
	GET_TBW
	tbw_init="${tbw}"; tbw2_init="${tbw2}"; tbw1_init="${tbw1}"
	tbw_time=(); tbw_time_old=()
	for i in 1 2 3 4 5 6; do tbw_time[i]="${tbw2}"; done
	for i in 1 2 3 4 5 6; do tbw_time_old[i]="${tbw2}"; done
}

TITLEMSG="WatchTBW:"
SET_INIT_DATA
MESSAGE="Data Units Written: $tbw_init"

# INIT
ROOT="/Users/$(whoami)/Library/Application Support/WatchTBW"
logfile="${ROOT}/tbwstat.log"
loc=$(defaults read -g AppleLocale | cut -d "_" -f1)
if [[ ! $loc = "ru" ]]; then loc="en"; fi
timer=0

DISPLAY_NOTIFICATION

# MAIN
while true
    do  
		
		tbw_old="${tbw}"; tbw1_old="${tbw1}"; tbw2_old="${tbw2}"
		if [[ $((timer%2)) = 0 ]]; then tbw_time_old[1]="${tbw2}"; fi
		if [[ $((timer%4)) = 0 ]]; then tbw_time_old[2]="${tbw2}"; fi
		if [[ $((timer%6)) = 0 ]]; then tbw_time_old[3]="${tbw2}"; fi
		if [[ $((timer%12)) = 0 ]]; then tbw_time_old[4]="${tbw2}"; fi
		if [[ $((timer%24)) = 0 ]]; then tbw_time_old[5]="${tbw2}"; fi
		if [[ $((timer%48)) = 0 ]]; then tbw_time_old[6]="${tbw2}"; fi
		SAVE_TBW_STAT
        sleep 1800
	    let "timer++"
	    GET_TBW
		if [[ $((tbw2-tbw2_old)) -ge 30 ]]; then SEND_WARNING; fi
		if [[ $((timer%2)) = 0 ]]; then tbw_time[1]="${tbw2}"; CHECK_ADD_WARNING 1; fi
		if [[ $((timer%4)) = 0 ]]; then tbw_time[2]="${tbw2}"; CHECK_ADD_WARNING 2; fi
		if [[ $((timer%6)) = 0 ]]; then tbw_time[3]="${tbw2}"; CHECK_ADD_WARNING 3; fi
		if [[ $((timer%12)) = 0 ]]; then tbw_time[4]="${tbw2}"; CHECK_ADD_WARNING 4; fi
		if [[ $((timer%24)) = 0 ]]; then tbw_time[5]="${tbw2}"; CHECK_ADD_WARNING 5; fi
		if [[ $((timer%48)) = 0 ]]; then tbw_time[6]="${tbw2}"; CHECK_ADD_WARNING 6; fi
		if [[ $timer -ge 48 ]]; then timer=1; SET_INIT_DATA; fi
    done

